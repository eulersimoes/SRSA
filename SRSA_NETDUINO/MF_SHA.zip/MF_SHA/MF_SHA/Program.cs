using System;
using System.Text;
using System.Threading;
using Microsoft.SPOT;

using ElzeKool;

namespace MF_SHA
{
    public class Program
    {
        public static void Main()
        {
            // Outputs: SHA-1: 6CD1F13BA07759CCB56D904C02C5509FCDEC30E2
            Debug.Print("SHA-1: " + HexDisplay.bytesToHex(SHA.computeSHA1(
                Encoding.UTF8.GetBytes("The quick brown fox jumped up the fence and fell down")
            )));

            // Outputs SHA-224: 475F234AC83E68834716DFF035A018AEFF5D575560B694EDD5FD40DE
            Debug.Print("SHA-224: " + HexDisplay.bytesToHex(SHA.computeSHA224(
                Encoding.UTF8.GetBytes("The quick brown fox jumped up the fence and fell down")
            )));

            // Outputs SHA-256: 8A1C5C14E24F5EA8F04061CA96A389DF77F838D0BEAD3253CFFEF8C880F912AA
            Debug.Print("SHA-256: " + HexDisplay.bytesToHex(SHA.computeSHA256(
                Encoding.UTF8.GetBytes("The quick brown fox jumped up the fence and fell down")
            )));

            // Outputs HMAC SHA-1: A31FBA759E7E25430CCC746800DFBA9926D3AAB9
            Debug.Print("HMAC SHA-1: " + HexDisplay.bytesToHex(SHA.computeHMAC_SHA1(
                Encoding.UTF8.GetBytes("testkey"),
                Encoding.UTF8.GetBytes("The quick brown fox jumped up the fence and fell down")
                )));
            
            // Outputs HMAC SHA-224: A36AA9599671BFA825BF8B1444F52E7266E4B0E2C30FD5D920EEA980
            Debug.Print("HMAC SHA-224: " + HexDisplay.bytesToHex(SHA.computeHMAC_SHA224(
                Encoding.UTF8.GetBytes("testkey"),
                Encoding.UTF8.GetBytes("The quick brown fox jumped up the fence and fell down")
            )));

            // Outputs HMAC SHA-256: 5AF95A03C056CED859AE31BB320BD620997544102BBFA487FB36CB4731B5A385
            Debug.Print("HMAC SHA-256: " + HexDisplay.bytesToHex(SHA.computeHMAC_SHA256(
                Encoding.UTF8.GetBytes("testkey"),
                Encoding.UTF8.GetBytes("The quick brown fox jumped up the fence and fell down")
            )));

            Thread.Sleep(-1);
        }

    }
}
